<?php 

$con=new mysqli("localhost","root","","bloodbank");
if($con->connect_error)
{
	echo "Database Connection Failed";
}

?>